
package lautaro.busico.p1.pkg322;


public class Piezas {
    String nombre;
    String ubicacion;
    CondicionClimatica condicionClimatica;

    public Piezas(String nombre, String ubicacion, CondicionClimatica condicionClimatica) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.condicionClimatica = condicionClimatica;
    }

    public String getNombre() {
        return nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public CondicionClimatica getCondicionClimatica() {
        return condicionClimatica;
    }

    public boolean piezaExiste(Piezas pieza){
        if(this.getNombre().equals(pieza.getNombre()) && this.getUbicacion().equals(pieza.getUbicacion())){
            return true;
        }
        return false;
    }

}
