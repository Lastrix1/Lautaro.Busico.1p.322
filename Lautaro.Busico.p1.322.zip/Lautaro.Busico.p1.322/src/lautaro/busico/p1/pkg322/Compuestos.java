
package lautaro.busico.p1.pkg322;

public enum Compuestos {
    SOFT,
    MEDIUM,
    HARD,
    WET;
}
