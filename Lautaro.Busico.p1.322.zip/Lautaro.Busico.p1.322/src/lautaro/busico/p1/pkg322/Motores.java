
package lautaro.busico.p1.pkg322;


public class Motores extends Piezas implements Ajustable{
    private double potenciaMaxima;

    public Motores(double potenciaMaxima, String nombre, String ubicacion, CondicionClimatica condicionClimatica) {
        super(nombre, ubicacion, condicionClimatica);
        this.potenciaMaxima = potenciaMaxima;
    }

    public double getPotenciaMaxima() {
        return potenciaMaxima;
    }


    @Override
    public void ajustar() {
        System.out.println("la pieza : "+this.getNombre()+" fue ajustada correctamente");
    }
    @Override
    public String toString(){
       StringBuilder sb = new StringBuilder();
        sb.append("la pieza: " + this.getNombre());
        sb.append(" en la ubicacion: "+this.getUbicacion());
        sb.append(" y la condicion Climatica ideal es: "+this.getCondicionClimatica());
        sb.append(" su potencia maxima es: "+this.getPotenciaMaxima());
        return sb.toString();
    }
    
    
}
