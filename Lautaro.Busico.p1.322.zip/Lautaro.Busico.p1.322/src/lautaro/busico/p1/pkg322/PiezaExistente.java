
package lautaro.busico.p1.pkg322;

public class PiezaExistente extends Exception {
    public PiezaExistente(String mensaje){
        super(mensaje);
    }
    
}
