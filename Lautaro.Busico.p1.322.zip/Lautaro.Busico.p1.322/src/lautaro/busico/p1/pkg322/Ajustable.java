
package lautaro.busico.p1.pkg322;


public interface Ajustable {
    public void ajustar();
}
