
package lautaro.busico.p1.pkg322;
import java.util.ArrayList;
public class Funcionalidades {
    private ArrayList<Piezas> listaDePiezas=new ArrayList<>();
    
    public void agregarPieza(Piezas pieza) throws PiezaExistente{
        if(verificacionPiezas(pieza)){
            throw new PiezaExistente("la pieza: "+pieza.getNombre()+" en la ubicacion: "+pieza.getUbicacion()+" ya existe");
        }
        listaDePiezas.add(pieza);
        
    }
    public void mostrarPiezas(){
        for (Piezas pieza:listaDePiezas){
            System.out.println(pieza.toString());
        }
    }
    public void ajustarPiezas(){
          for (Piezas pieza:listaDePiezas){
            if (pieza instanceof Neumaticos){
                System.out.println("Los neumaticos No se pueden ajustar");
                continue;
            }
            ((Ajustable)pieza).ajustar();
        }
    }
    public void buscarPiezaPorCondicion(CondicionClimatica condicion){
        ArrayList<Piezas> listaFiltrada=new ArrayList<>();
        int contador=0;
        for(Piezas pieza:listaDePiezas){
            if (pieza.getCondicionClimatica().equals(condicion)){
                listaFiltrada.add(pieza);
                pieza.toString();
                contador++;
            }
            
            
        }
        if(contador==0){
                System.out.println("ninguna pieza se a encontrado con el la condicion climatica de " + condicion);
            }
    }
    public boolean verificacionPiezas(Piezas piezas){
        for (Piezas pieza : listaDePiezas){
            if (piezas.piezaExiste(pieza))
            {
                return true;
            }
            
        }
        return false;
        
    }
}
