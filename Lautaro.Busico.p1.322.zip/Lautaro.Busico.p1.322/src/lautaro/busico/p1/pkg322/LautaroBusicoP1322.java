/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lautaro.busico.p1.pkg322;

/**
 *
 * @author busic
 */
public class LautaroBusicoP1322 {
    
    public static void main(String[] args) throws PiezaExistente{
       Funcionalidades funcional= new Funcionalidades();
       
       funcional.agregarPieza(new Motores(18.2,"PU-016","sala de motores",CondicionClimatica.SECO));
       funcional.agregarPieza(new Motores(18.3,"PU-086","sala de motores",CondicionClimatica.SECO));
       funcional.agregarPieza(new Motores(18.3,"PU-816","sala de motores",CondicionClimatica.MIXTO));
       funcional.agregarPieza(new Alas(10,"PU-916","sala de Alas",CondicionClimatica.SECO));
       funcional.agregarPieza(new Neumaticos(Compuestos.WET,"pireli-soft","sala de neumaticos",CondicionClimatica.MOJADO));
       
       funcional.mostrarPiezas();
       funcional.ajustarPiezas();
       funcional.buscarPiezaPorCondicion(CondicionClimatica.SECO);
       
    }

}