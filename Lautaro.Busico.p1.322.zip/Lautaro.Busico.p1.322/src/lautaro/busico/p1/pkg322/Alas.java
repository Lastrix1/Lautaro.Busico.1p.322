
package lautaro.busico.p1.pkg322;

public class Alas extends Piezas implements Ajustable {
    private int cargaAerodinamica;
    private int Maximo = 10;
    private int Minimo=1;

    public Alas(int cargaAerodinamica, String nombre, String ubicacion, CondicionClimatica condicionClimatica) throws CargaExedida {
        super(nombre, ubicacion, condicionClimatica);
        if (verificarCargaCorecta(cargaAerodinamica)){
            throw new CargaExedida("la carga aerodinamica esta fuera del limite");
        }
        this.cargaAerodinamica = cargaAerodinamica;
    }

    public int getCargaAerodinamica() {
        return cargaAerodinamica;
    }

   @Override
    public void ajustar() {
        System.out.println("la pieza : "+this.getNombre()+" fue ajustada correctamente");
    }
    @Override
    public String toString(){
       StringBuilder sb = new StringBuilder();
        sb.append("la pieza: " + this.getNombre());
        sb.append(" en la ubicacion: "+this.getUbicacion());
        sb.append(" y la condicion Climatica ideal es: "+this.getCondicionClimatica());
        sb.append(" su carga aerodinamica es: "+this.getCargaAerodinamica());
        return sb.toString();
    }    
    private boolean verificarCargaCorecta(int piezaACargar){
        if (piezaACargar>Maximo || piezaACargar<Minimo){
            return true;
        }
        return false;
    }
    
}
