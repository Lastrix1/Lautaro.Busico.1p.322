
package lautaro.busico.p1.pkg322;


public enum CondicionClimatica {
    SECO,
    MOJADO,
    MIXTO;
    
}
