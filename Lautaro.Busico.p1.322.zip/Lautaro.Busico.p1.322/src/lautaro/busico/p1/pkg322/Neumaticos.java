
package lautaro.busico.p1.pkg322;


public class Neumaticos extends Piezas{
    private Compuestos compuesto;

    public Neumaticos(Compuestos compuesto, String nombre, String ubicacion, CondicionClimatica condicionClimatica) {
        super(nombre, ubicacion, condicionClimatica);
        this.compuesto = compuesto;
    }

    public Compuestos getCompuesto() {
        return compuesto;
    }
    
    @Override
    public String toString(){
       StringBuilder sb = new StringBuilder();
        sb.append("la pieza: " + this.getNombre());
        sb.append(" en la ubicacion: "+this.getUbicacion());
        sb.append(" y la condicion Climatica ideal es: "+this.getCondicionClimatica());
        sb.append(" su carga aerodinamica es: "+this.getCompuesto());
        return sb.toString();
    }    
    
   
    
    
}
