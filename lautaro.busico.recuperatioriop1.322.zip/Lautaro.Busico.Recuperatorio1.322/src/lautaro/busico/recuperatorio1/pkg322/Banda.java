
package lautaro.busico.recuperatorio1.pkg322;

public class Banda extends Presentacion implements Tocable{
  private int maximoDeIntegrantes=10;

    public Banda(String nombrePresentacion, String escenario, TipoEscenario tipo,int integrantes)throws MaximoCumplido {
        super(nombrePresentacion, escenario, tipo);
        if(integrantes>maximoDeIntegrantes){
          throw new MaximoCumplido("integrantes maximos");
        }
    }

    @Override
    public String toString() {
        return "Banda{" + "maximoDeIntegrantes=" + maximoDeIntegrantes + '}';
    }
    @Override
    public void tocarEnVivo() {
        System.out.println("tocaste en vivo");
    }
    
    
  
}
