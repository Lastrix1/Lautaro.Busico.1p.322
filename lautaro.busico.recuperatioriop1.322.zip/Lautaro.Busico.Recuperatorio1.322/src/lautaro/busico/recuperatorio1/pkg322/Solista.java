/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lautaro.busico.recuperatorio1.pkg322;

/**
 *
 * @author busic
 */
public class Solista extends Presentacion implements Animable,Tocable{
    private TipoDeInstrumento instrumentoFavorito;

    public Solista(String nombrePresentacion, String escenario, TipoEscenario tipo,TipoDeInstrumento instrumentoFavorito) {
        this.instrumentoFavorito=instrumentoFavorito;
        super(nombrePresentacion, escenario, tipo);
    }

    @Override
    public String toString() {
        return "Solista{" + "instrumentoFavorito=" + instrumentoFavorito + '}';
    }

    @Override
    public void animarAlPublico() {
        System.out.println("animaste al publico");
    }

    @Override
    public void tocarEnVivo() {
        System.out.println("tocaste en vivo");
    }
    
    
}
