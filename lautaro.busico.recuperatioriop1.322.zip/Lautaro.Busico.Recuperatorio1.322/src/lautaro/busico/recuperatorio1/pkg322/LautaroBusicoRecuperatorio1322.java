/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lautaro.busico.recuperatorio1.pkg322;

import java.util.ArrayList;

/**
 *
 * @author busic
 */
public class LautaroBusicoRecuperatorio1322 {
    public static void main(String[] args)throws MaximoCumplido,PresentacionExistente {
    
        GestionDePresentacion sistema = new GestionDePresentacion();

        
        try {
           
            sistema.agregarPresentacion(new Banda("Los Relampagos", "Escenario Principal", TipoEscenario.EXTERIOR,5));
            sistema.agregarPresentacion(new Solista("Ana Torres", "Escenario Secundario", TipoEscenario.INTERIOR, TipoDeInstrumento.GUITARRA));
            sistema.agregarPresentacion(new Dj("DJ Nano", "After Stage", TipoEscenario.EXTERIOR, EstiloMusical.HOUSE));

           
            sistema.agregarPresentacion(new Banda("Los Relampagos", "Escenario Principal", TipoEscenario.EXTERIOR, 5));
        } catch (PresentacionExistente e) {
            System.out.println("Error al agregar presentacion: " + e.getMessage());
        }
        catch (MaximoCumplido f){
            System.out.println("Error al agregar presentacion: " + f.getMessage());
        }

       
        System.out.println("\n--- Mostrar presentaciones ---");
        sistema.mostrarPresentacion();

     
        System.out.println("\n--- Probar tocarEnVivo ---");
       
        sistema.tocarVivo();

       
        System.out.println("\n--- Probar animarPublico ---");
        sistema.animarPublico();

        
        System.out.println("\n--- Filtrar por TipoEscenario: EXTERIOR ---");
        ArrayList<Presentacion> filtradas =sistema.filtrarPorTipoDeEscenario(TipoEscenario.EXTERIOR);
     
   
        System.out.println("\n--- Eliminar presentaciones por tipo: DJ ---");
      
        sistema.eliminarPorTipo(TipoEscenario.INTERIOR);

   
        System.out.println("\n--- Mostrar presentaciones (despues de eliminar DJs) ---");
        sistema.mostrarPresentacion();
    }
}

