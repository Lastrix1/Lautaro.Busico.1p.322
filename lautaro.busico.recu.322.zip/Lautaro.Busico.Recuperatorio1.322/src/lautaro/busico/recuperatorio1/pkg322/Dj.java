/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lautaro.busico.recuperatorio1.pkg322;

/**
 *
 * @author busic
 */
public class Dj extends Presentacion implements Animable  {
    private EstiloMusical estilODeMusica;

    public Dj(String nombrePresentacion, String escenario, TipoEscenario tipo,EstiloMusical estilODeMusica) {
        super(nombrePresentacion, escenario, tipo);
        this.estilODeMusica=estilODeMusica;
    }

    @Override
    public String toString() {
        return "Dj{" +super.toString()+ "estilODeMusica=" + estilODeMusica + '}';
    }

    @Override
    public void animarAlPublico() {
        System.out.println("animaste al publico");
    }
    
}
