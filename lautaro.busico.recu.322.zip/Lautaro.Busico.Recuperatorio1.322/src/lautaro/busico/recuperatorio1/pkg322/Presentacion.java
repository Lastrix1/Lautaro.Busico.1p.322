/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lautaro.busico.recuperatorio1.pkg322;

/**
 *
 * @author busic
 */
public class Presentacion {
   private String nombrePresentacion;
   private String escenario;
   private TipoEscenario tipo;

    public Presentacion(String nombrePresentacion, String escenario, TipoEscenario tipo) {
        this.nombrePresentacion = nombrePresentacion;
        this.escenario = escenario;
        this.tipo = tipo;
    }

    public String getNombrePresentacion() {
        return nombrePresentacion;
    }

    public String getEscenario() {
        return escenario;
    }

    public TipoEscenario getTipo() {
        return tipo;
    }
    @Override
    public boolean equals(Object o){
        if(this==o)return true;
        if(!(o instanceof Presentacion))return false;
        Presentacion presentacion =(Presentacion)o;
        return this.getEscenario().equals(presentacion.escenario) && this.nombrePresentacion.equals(presentacion.nombrePresentacion);
    }
    protected String muestra(){
        StringBuilder sb= new StringBuilder();
        sb.append ("Nombre proyecto: " + this.getNombrePresentacion() + " ");
        sb.append ("Estado actual: " + this.getEscenario() + " ");
        sb.append ("Atributo del proyecto " + this.getTipo() + " ");
        return(sb.toString());
    }
    @Override
    public String toString(){
        return this.muestra();
    }
}
        
        
        
        
 
   


