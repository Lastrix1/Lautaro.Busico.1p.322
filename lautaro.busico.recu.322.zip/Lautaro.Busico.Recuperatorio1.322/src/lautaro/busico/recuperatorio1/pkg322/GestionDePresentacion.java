/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lautaro.busico.recuperatorio1.pkg322;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author busic
 */
public class GestionDePresentacion {
    private ArrayList<Presentacion> listaDePresentacion = new ArrayList<>();
        public void agregarPresentacion(Presentacion presentacion) throws PresentacionExistente {
        if (listaDePresentacion.contains(presentacion)) {
            throw new PresentacionExistente("la pieza: " + presentacion.getNombrePresentacion() + " en la ubicacion: " + presentacion.getEscenario() + " ya existe");
        }
        listaDePresentacion.add(presentacion);

    }
        public void mostrarPresentacion() {
        for (Presentacion presentacion : listaDePresentacion) {
            System.out.println(presentacion.toString());
        }
        }
    public void tocarVivo(){
            for (Presentacion presentacion : listaDePresentacion) {
            if(!(presentacion instanceof Tocable)){
                    System.out.println("el "+presentacion.getNombrePresentacion()+" no toca");
                    continue;
                }
            ((Tocable) presentacion).tocarEnVivo();
            }
        }
    public void animarPublico(){
     for (Presentacion presentacion : listaDePresentacion) {
            if(!(presentacion instanceof Animable)){
                    System.out.println("el "+presentacion.getNombrePresentacion()+"no Puede Animar");
                    continue;
                }
            ((Animable) presentacion).animarAlPublico();
            }
    }
    
        public ArrayList<Presentacion> filtrarPorTipoDeEscenario(TipoEscenario tipo) {
         ArrayList<Presentacion> listaDePresentacionFiltrada = new ArrayList<>();
        for (Presentacion presentacion : listaDePresentacion) {
            if (presentacion.getTipo().equals(tipo)) {
                System.out.println(presentacion.toString());
                listaDePresentacionFiltrada.add(presentacion);
            }        
        }
            return listaDePresentacionFiltrada;
        }
        
    public void eliminarPorTipo(TipoEscenario tipo) {
        Iterator<Presentacion> iteracion = listaDePresentacion.iterator();
        while (iteracion.hasNext()) {
            Presentacion p = iteracion.next();
        if (p.getTipo().equals(tipo)) {
            iteracion.remove();
        }
    }
}
}



    




